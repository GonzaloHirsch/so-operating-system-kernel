#ifndef TIME_H
#define TIME_H

//#include <lib.h>

void timer_handler();
int ticks_elapsed();

#endif
